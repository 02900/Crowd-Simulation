﻿using UnityEngine;

namespace OpenSteer
{
    public abstract class ProximityDatabaseItem : MonoBehaviour
    {
        // The virtual interface used by objects in the spatial database.
    }
}
